import { Foundation } from './foundation.core';

import { ResponsiveAccordionTabs } from '../../foundation.responsiveAccordionTabs';
Foundation.plugin(ResponsiveAccordionTabs, 'ResponsiveAccordionTabs');

export { Foundation, ResponsiveAccordionTabs };
