import { Foundation } from './foundation.core';

import { Tabs } from '../../foundation.tabs';
Foundation.plugin(Tabs, 'Tabs');

export { Foundation, Tabs };
