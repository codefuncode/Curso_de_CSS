import { Foundation } from './foundation.core';

import { Magellan } from '../../foundation.magellan';
Foundation.plugin(Magellan, 'Magellan');

export { Foundation, Magellan };
