import { Foundation } from './foundation.core';

import { Abide } from '../../foundation.abide';
Foundation.plugin(Abide, 'Abide');

export { Foundation, Abide };
