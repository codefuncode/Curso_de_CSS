describe('Responsive Menu', function() {
	var plugin;
	var $html;

	// afterEach(function() {
	// 	plugin.destroy();
	// 	$html.remove();
	// });

	describe('constructor()', function() {
		// it('', function() {
		// 	$html = $('').appendTo('body');
		// 	plugin = new Foundation.ResponsiveMenu($html, {});

		// 	plugin.$element.should.be.an('object');
		// 	plugin.options.should.be.an('object');
		// });
	});

});