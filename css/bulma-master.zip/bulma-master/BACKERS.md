# Backers via Patreon

<div class="bd-content">
          

<h2 class="title is-5">
  Generous backers ($30+)
</h2>

<table class="table is-bordered">
  
<thead>
  <tr>
    <th>Name</th>
    <th>Twitter</th>
    <th>Website</th>
  </tr>
</thead>

  <tbody>
    
      <tr>
  <td>Adrian Ocneanu</td>

  <td>
    
      <a href="https://twitter.com/aocneanu" target="_blank" rel="nofollow">
        @aocneanu
      </a>
    
  </td>

  <td>
    
      <a href="https://www.earthlink.ro/" target="_blank" rel="nofollow">
        Earthlink
      </a>
    
  </td>
</tr>

    
      <tr>
  <td>Garry Newman</td>

  <td>
    
      <a href="https://twitter.com/garrynewman" target="_blank" rel="nofollow">
        @garrynewman
      </a>
    
  </td>

  <td>
    
  </td>
</tr>

    
    
  </tbody>
</table>



<h2 class="title is-5">
  Homepage sponsors ($100+)
</h2>

<table class="table is-bordered">
  
<thead>
  <tr>
    <th>Name</th>
    <th>Twitter</th>
    <th>Website</th>
  </tr>
</thead>

  <tbody>
    
      <tr>
  <td>Robert Bolder</td>

  <td>
    
  </td>

  <td>
    
  </td>
</tr>

    
      <tr>
  <td>Sparheld International GmbH</td>

  <td>
    
  </td>

  <td>
    
  </td>
</tr>

    
      <tr>
  <td>Adela Belin</td>

  <td>
    
  </td>

  <td>
    
  </td>
</tr>

    
      <tr>
  <td>Iaroslav Baklan</td>

  <td>
    
  </td>

  <td>
    
  </td>
</tr>

    
      <tr>
  <td>Fintan Costello</td>

  <td>
    
  </td>

  <td>
    
  </td>
</tr>

    
      <tr>
  <td>MonoVM </td>

  <td>
    
  </td>

  <td>
    
  </td>
</tr>

    
      <tr>
  <td>Raj.bet</td>

  <td>
    
  </td>

  <td>
    
  </td>
</tr>

    
    
      <tr>
  <td>brabusdot</td>
  <td colspan="2"><a href="https://github.com/brabusdot" target="_blank" rel="nofollow">GitHub</a></td>
</tr>

    
      <tr>
  <td>Pillarwm</td>
  <td colspan="2"><a href="https://github.com/Pillarwm" target="_blank" rel="nofollow">GitHub</a></td>
</tr>

    
      <tr>
  <td>airtract</td>
  <td colspan="2"><a href="https://github.com/airtract" target="_blank" rel="nofollow">GitHub</a></td>
</tr>

    
      <tr>
  <td>patrick136</td>
  <td colspan="2"><a href="https://github.com/patrick136" target="_blank" rel="nofollow">GitHub</a></td>
</tr>

    
  </tbody>
</table>

<h2 class="title is-5">
  Bulma backers ($10+)
</h2>

<table class="table is-bordered">
  
<thead>
  <tr>
    <th>Name</th>
    <th>Twitter</th>
    <th>Website</th>
  </tr>
</thead>

  <tbody>
    
      <tr>
  <td>Jordan Nemrow</td>

  <td>
    
  </td>

  <td>
    
  </td>
</tr>

    
      <tr>
  <td>Stuart Stanfield</td>

  <td>
    
  </td>

  <td>
    
  </td>
</tr>

    
      <tr>
  <td>Jason Seminara</td>

  <td>
    
  </td>

  <td>
    
  </td>
</tr>

    
      <tr>
  <td>Al Romano</td>

  <td>
    
  </td>

  <td>
    
  </td>
</tr>

    
      <tr>
  <td>xvxx</td>

  <td>
    
  </td>

  <td>
    
  </td>
</tr>

    
      <tr>
  <td>Maurice Perry</td>

  <td>
    
  </td>

  <td>
    
  </td>
</tr>

    
    
      <tr>
  <td>mieko</td>
  <td colspan="2"><a href="https://github.com/mieko" target="_blank" rel="nofollow">GitHub</a></td>
</tr>

    
      <tr>
  <td>mmmonica50</td>
  <td colspan="2"><a href="https://github.com/mmmonica50" target="_blank" rel="nofollow">GitHub</a></td>
</tr>

    
      <tr>
  <td>nafSadh</td>
  <td colspan="2"><a href="https://github.com/nafSadh" target="_blank" rel="nofollow">GitHub</a></td>
</tr>

    
      <tr>
  <td>linkdd</td>
  <td colspan="2"><a href="https://github.com/linkdd" target="_blank" rel="nofollow">GitHub</a></td>
</tr>

    
      <tr>
  <td>seansan</td>
  <td colspan="2"><a href="https://github.com/seansan" target="_blank" rel="nofollow">GitHub</a></td>
</tr>

    
      <tr>
  <td>sasmithjr</td>
  <td colspan="2"><a href="https://github.com/sasmithjr" target="_blank" rel="nofollow">GitHub</a></td>
</tr>

    
      <tr>
  <td>Gomah</td>
  <td colspan="2"><a href="https://github.com/Gomah" target="_blank" rel="nofollow">GitHub</a></td>
</tr>

    
  </tbody>
</table>

        </div>
